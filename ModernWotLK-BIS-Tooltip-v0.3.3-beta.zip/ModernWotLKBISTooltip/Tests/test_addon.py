from pathlib import Path
import sys
# Requires lupa==2.8
sys.path.insert(0,str(Path('work/test033-deps').resolve()))
from lupa.lua51 import LuaRuntime
root=Path(__file__).resolve().parent.parent
lua=LuaRuntime(unpack_returned_tuples=True)
lua.execute('''
function GetBuildInfo() return '3.3.5' end
function GetRealmName() return 'Icecrown' end
function CreateFrame() return {RegisterEvent=function()end,SetScript=function()end} end
SlashCmdList={}; DEFAULT_CHAT_FRAME={AddMessage=function()end}
function UnitClass() return 'Warrior','WARRIOR' end
function GetActiveTalentGroup() return 1 end
function GetTalentTabInfo(i) return '', '', i==2 and 51 or 0 end
function Font()
 local f={text='',color={1,1,1},shown=true,font={'test.ttf',14,''}}
 function f:GetFont() return unpack(self.font) end
 function f:SetFont(...) self.font={...} end
 function f:GetText() return self.text end
 function f:SetText(t) self.text=t end
 function f:GetTextColor() return unpack(self.color) end
 function f:SetTextColor(...) self.color={...} end
 function f:Show() self.shown=true end
 function f:Hide() self.shown=false end
 function f:IsShown() return self.shown end
 return f
end
function Tip(name)
 local t={name=name,n=0,hooks={},shows=0}
 function t:GetName() return self.name end
 function t:SetClampedToScreen(value) self.clamped=value end
 function t:GetItem() return 'Item',self.link end
 function t:NumLines() return self.n end
 function t:GetRegions() return self.coin end
 function t:GetChildren() end
 function t:AddDoubleLine(l,r)
  self.n=self.n+1
  for _,side in ipairs({'Left','Right'}) do
   local f=Font(); f:SetText(side=='Left' and l or r)
   _G[self.name..'Text'..side..self.n]=f
  end
 end
 function t:HookScript(k,f) self.hooks[k]=f end
 function t:Show() self.shows=self.shows+1 end
 function t:Reset(id)
  self.n=0; self.link='item:'..id
  if self.hooks.OnTooltipCleared then self.hooks.OnTooltipCleared() end
 end
 return t
end
GameTooltip=Tip('GameTooltip'); ItemRefTooltip=Tip('ItemRefTooltip')
''')
for file in ['Core.lua','Database.lua','Profiles.lua','Tooltip.lua']:
    lua.execute((root/file).read_text('ascii'),name=file)
lua.execute('''
local A=ModernWotLKBIS
A:UpdateSpec(); assert(A.spec=='WARRIOR_2')
assert(#A:DisplayLines(1)==0)
local lines=A:DisplayLines(54590)
local warriors=0
for _,s in ipairs(lines) do if s=='|cffc79c6eWarrior|r' then warriors=warriors+1 end end
assert(warriors==1) -- One heading even with Arms and Fury assessments.
for _,t in ipairs({GameTooltip,ItemRefTooltip}) do
 t:Reset(54590)
 t:AddDoubleLine('Item',''); t:AddDoubleLine('Equip: stats','')
 t:AddDoubleLine('|cffffff00Vendor x1|r','11g 39s 40c')
 t:AddDoubleLine('Auction x1','unknown'); t:AddDoubleLine('Disenchant x1','unknown')
 local coin={relative=_G[t.name..'TextLeft3']}
 function coin:GetObjectType() return 'Texture' end
 function coin:GetNumPoints() return 1 end
 function coin:GetPoint() return 'LEFT',self.relative,'RIGHT',2,0 end
 function coin:ClearAllPoints() end
 function coin:SetPoint(p,r) self.relative=r end
 t.coin=coin
 t.hooks.OnTooltipSetItem(t)
 assert(t.n==5+#lines)
 assert(math.abs(_G[t.name..'TextLeft3'].font[2]-11.2)<0.001)
 assert(_G[t.name..'TextLeft'..(3+#lines)].font[2]==14)
 assert(_G[t.name..'TextLeft3']:GetText()==lines[1])
 assert(_G[t.name..'TextRight'..(3+#lines)]:GetText()=='11g 39s 40c')
 assert(coin.relative==_G[t.name..'TextLeft'..(3+#lines)])
 local shows=t.shows
 for i=1,100 do t.hooks.OnUpdate(t,0.11) end
 assert(t.n==5+#lines and t.shows==shows)
 local reused=_G[t.name..'TextLeft3']
 t:Reset(1); assert(reused.font[2]==14)
 t:AddDoubleLine('Unknown',''); t.hooks.OnTooltipSetItem(t); assert(t.n==1)
 t:Reset(54590); t:AddDoubleLine('Item',''); t.hooks.OnTooltipSetItem(t)
 t:AddDoubleLine('Vendor x1','5g'); t.hooks.OnUpdate(t,0.11)
 assert(t.n==2+#lines and _G[t.name..'TextLeft2']:GetText()==lines[1])
 -- Pricing inserted by another addon before our existing block.
 t:Reset(54590); t:AddDoubleLine('Item',''); t.hooks.OnTooltipSetItem(t)
 t:AddDoubleLine(' ','')
 for i=t.n,3,-1 do
  _G[t.name..'TextLeft'..i]:SetText(_G[t.name..'TextLeft'..(i-1)]:GetText())
 end
 _G[t.name..'TextLeft2']:SetText('Auction x1')
 t.hooks.OnUpdate(t,0.11)
 assert(t.n==2+#lines and _G[t.name..'TextLeft2']:GetText()==lines[1])
 assert(_G[t.name..'TextLeft'..t.n]:GetText()=='Auction x1')
end
''')

lua.execute("""
local A=ModernWotLKBIS
assert(A:ItemID('|Hitem:49623:0:0:0:0:0:0:0|h[Warglaives appearance]|h')==49623)
assert(A:DetectProfile('Lordaeron')=='lordaeron')
assert(A:DetectProfile('Other server')=='generic')
assert(A.items[39714].specs.ROGUE_1.label=='ALT 1')
assert(A.items[45607].specs.ROGUE_1.label=='ALT 2')
assert(A.items[49623].specs.PALADIN_3.label=='BIS 4')
""")
print('PASS: Lua 5.1 load, tooltip regression tests, original item ID, profiles, phase 1/2 labels.')


lua.execute("""
local A=ModernWotLKBIS
assert(A.items[45931].specs.DRUID_2_CAT.label=='ALT 3')
assert(A.items[40516].specs.SHAMAN_1.label=='ALT 1')
assert(A.items[50735].specs.DRUID_2_BEAR.label=='BIS 4')
local items,assessments=0,0
for id,item in pairs(A.items) do
 items=items+1
 for spec,r in pairs(item.specs) do
  assessments=assessments+1
  assert(A.specNames[spec] and #r.sources>0)
  for _,ref in ipairs(r.sources) do assert(A.sources[ref]) end
 end
end
assert(items==599 and assessments==1124)
""")
print('PASS: expanded database counts, source references and historical phase labels.')

lua.execute("""
local A=ModernWotLKBIS
assert(A.items[49623].specs.WARRIOR_1.label=='BIS 4')
assert(A.items[49623].specs.WARRIOR_2.label=='BIS 4')
local grouped=false
for _,line in ipairs(A:DisplayLines(49623)) do
 if string.find(line,'ARMS, FURY',1,true) then grouped=true end
end
assert(grouped)
""")
print('PASS: Arms and Fury Shadowmourne grouping.')

lua.execute("""
local A=ModernWotLKBIS
for _,id in ipairs({50765,50766,50767,50768,50769,51175,51176,51177,51178,51179}) do
 assert(A.items[id].specs.PRIEST_1.label=='ALT 4')
 assert(#A:DisplayLines(id)>0)
 assert(not A.items[id].specs.PRIEST_3)
end
assert(A.items[51263].specs.PRIEST_1.label=='BIS 4')
""")
print('PASS: Priest healing tier alternatives and unchanged heroic rating.')

import zipfile,json
old=LuaRuntime(unpack_returned_tuples=True)
old.execute('ModernWotLKBIS={compatible=true}')
with zipfile.ZipFile('outputs/ModernWotLK-BIS-Tooltip-v0.3.2-beta.zip') as z:
 old.execute(z.read('ModernWotLKBISTooltip/Database.lua').decode('ascii'))
for item,record in old.globals().ModernWotLKBIS['items'].items():
 for spec,assessment in record.specs.items():
  assert lua.globals().ModernWotLKBIS['items'][item].specs[spec].label==assessment.label
audit=json.loads((root/'VARIANT-AUDIT.json').read_text())
for row in audit:
 assessment=lua.globals().ModernWotLKBIS['items'][row['item']].specs[row['spec']]
 assert assessment.label.startswith('ALT ') and assessment.conditional
 assert len(lua.globals().ModernWotLKBIS.DisplayLines(lua.globals().ModernWotLKBIS,row['item']))>0
assert len(audit)==421
print('PASS: all prior ratings unchanged; all 421 variant assessments render as conditional ALT.')
